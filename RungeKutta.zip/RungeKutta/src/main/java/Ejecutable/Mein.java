package Ejecutable;

public class Mein {
    public static void main(String[] args) {
        EjecutableRunge Ejecutable=new EjecutableRunge();
        Ejecutable.process();
    }
}
